var group___n_a_n_d__events =
[
    [ "ARM_NAND_EVENT_DEVICE_READY", "group___n_a_n_d__events.html#gae0be7e1b41188def905de0a1568d442d", null ],
    [ "ARM_NAND_EVENT_DRIVER_DONE", "group___n_a_n_d__events.html#gac774a334871789d24107b843d1ebd00c", null ],
    [ "ARM_NAND_EVENT_DRIVER_READY", "group___n_a_n_d__events.html#ga7b390a906db42c5ea4db38e0e85bb9e9", null ],
    [ "ARM_NAND_EVENT_ECC_ERROR", "group___n_a_n_d__events.html#ga7bee0c32528ab991c0c064f895f80664", null ]
];