var group__sai__mode__control =
[
    [ "ARM_SAI_MODE_MASTER", "group__sai__mode__control.html#ga5bedff714ea0f90139665b72d44daddc", null ],
    [ "ARM_SAI_MODE_SLAVE", "group__sai__mode__control.html#ga5956c12a24a506754ecc7999f0660bb5", null ]
];