var group__eth__phy__mode__ctrls =
[
    [ "ARM_ETH_PHY_AUTO_NEGOTIATE", "group__eth__phy__mode__ctrls.html#ga6a8c54f8fed3e5f68bd04eb715d10ab9", null ],
    [ "ARM_ETH_PHY_DUPLEX_FULL", "group__eth__phy__mode__ctrls.html#ga5d06a94867c89cd311b6e279669321e3", null ],
    [ "ARM_ETH_PHY_DUPLEX_HALF", "group__eth__phy__mode__ctrls.html#gace797b3cd143be22f47c3ef61b20e14d", null ],
    [ "ARM_ETH_PHY_ISOLATE", "group__eth__phy__mode__ctrls.html#ga8d68719e07c7af449b57c5df802376c8", null ],
    [ "ARM_ETH_PHY_LOOPBACK", "group__eth__phy__mode__ctrls.html#ga5f7e46cda8ab3c774fe7ce0a8a1ba3ec", null ],
    [ "ARM_ETH_PHY_SPEED_100M", "group__eth__phy__mode__ctrls.html#gad1e8b2c8c210fa36949db9a34a993657", null ],
    [ "ARM_ETH_PHY_SPEED_10M", "group__eth__phy__mode__ctrls.html#gabc7acc4ebe828c3d0825400e14ad20f0", null ],
    [ "ARM_ETH_PHY_SPEED_1G", "group__eth__phy__mode__ctrls.html#ga046605398ceae99a176e6f82432ae710", null ]
];