var group__sai__mclk__pin__control =
[
    [ "ARM_SAI_MCLK_PIN_INACTIVE", "group__sai__mclk__pin__control.html#ga7654bffb42e96d48df57c598323337d6", null ],
    [ "ARM_SAI_MCLK_PIN_INPUT", "group__sai__mclk__pin__control.html#ga2cd610be9ba9532b2926376deaacf5ad", null ],
    [ "ARM_SAI_MCLK_PIN_OUTPUT", "group__sai__mclk__pin__control.html#ga24d99edf05699eff32da02742fb04ced", null ]
];