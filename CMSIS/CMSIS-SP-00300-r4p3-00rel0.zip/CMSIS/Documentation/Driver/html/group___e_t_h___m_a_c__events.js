var group___e_t_h___m_a_c__events =
[
    [ "ARM_ETH_MAC_EVENT_RX_FRAME", "group___e_t_h___m_a_c__events.html#ga76943471a4a3e9e8c1ff9fe83e43bd47", null ],
    [ "ARM_ETH_MAC_EVENT_TIMER_ALARM", "group___e_t_h___m_a_c__events.html#ga4afc71ecac964f195e27be4acdbe7c61", null ],
    [ "ARM_ETH_MAC_EVENT_TX_FRAME", "group___e_t_h___m_a_c__events.html#ga0c0328ff7cf886d5fdb53bb84ec03c1b", null ],
    [ "ARM_ETH_MAC_EVENT_WAKEUP", "group___e_t_h___m_a_c__events.html#ga1f3bdb219afa8f2a121b58cc84f5761c", null ]
];