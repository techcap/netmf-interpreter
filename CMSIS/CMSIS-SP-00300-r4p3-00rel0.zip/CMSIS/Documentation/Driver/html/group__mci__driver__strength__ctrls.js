var group__mci__driver__strength__ctrls =
[
    [ "ARM_MCI_DRIVER_TYPE_A", "group__mci__driver__strength__ctrls.html#ga64eb1c4847711a262f084c361b60a912", null ],
    [ "ARM_MCI_DRIVER_TYPE_B", "group__mci__driver__strength__ctrls.html#ga078d3c3bc7c9335b92e6445a0abafc46", null ],
    [ "ARM_MCI_DRIVER_TYPE_C", "group__mci__driver__strength__ctrls.html#ga3da11696d1fcd3930eb7e70fe097d747", null ],
    [ "ARM_MCI_DRIVER_TYPE_D", "group__mci__driver__strength__ctrls.html#ga8185f82b1d8857a3f0eb461d664f2b3d", null ]
];