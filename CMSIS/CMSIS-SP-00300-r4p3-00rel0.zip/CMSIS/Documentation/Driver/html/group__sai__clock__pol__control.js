var group__sai__clock__pol__control =
[
    [ "ARM_SAI_CLOCK_POLARITY_0", "group__sai__clock__pol__control.html#ga4311b6b6fd937d6ac37aa2d031a5d5ee", null ],
    [ "ARM_SAI_CLOCK_POLARITY_1", "group__sai__clock__pol__control.html#gae4c9b9abd3b7390810a5494363875a53", null ]
];