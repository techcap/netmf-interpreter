var group___s_a_i__events =
[
    [ "ARM_SAI_EVENT_FRAME_ERROR", "group___s_a_i__events.html#ga6ffcf96fe404b48421a57fbd122b26bc", null ],
    [ "ARM_SAI_EVENT_RECEIVE_COMPLETE", "group___s_a_i__events.html#ga5a9bde0b096aafe53279529a0adbef55", null ],
    [ "ARM_SAI_EVENT_RX_OVERFLOW", "group___s_a_i__events.html#gac83e9df0238803ef2c88f16605f73bf5", null ],
    [ "ARM_SAI_EVENT_SEND_COMPLETE", "group___s_a_i__events.html#ga3dfa64375859f40d157c224187d2885e", null ],
    [ "ARM_SAI_EVENT_TX_UNDERFLOW", "group___s_a_i__events.html#ga6a0be7aaf9d700e5259f741641bc37ca", null ]
];