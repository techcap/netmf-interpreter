var group__sai__bit__order__control =
[
    [ "ARM_SAI_LSB_FIRST", "group__sai__bit__order__control.html#ga19b51b75537b030b975efcf68f3db78b", null ],
    [ "ARM_SAI_MSB_FIRST", "group__sai__bit__order__control.html#gaf74bfe9c3005bf3b80d69f112ea9e62b", null ]
];