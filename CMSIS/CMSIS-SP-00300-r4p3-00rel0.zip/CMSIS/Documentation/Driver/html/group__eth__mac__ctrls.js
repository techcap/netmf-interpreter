var group__eth__mac__ctrls =
[
    [ "ARM_ETH_MAC_CONFIGURE", "group__eth__mac__ctrls.html#ga7819c7a1aa7bbc13dc42d0fd7e75a23c", null ],
    [ "ARM_ETH_MAC_CONTROL_RX", "group__eth__mac__ctrls.html#gae0964364b81b38b6e1fbf7196f3be869", null ],
    [ "ARM_ETH_MAC_CONTROL_TX", "group__eth__mac__ctrls.html#ga3a98c8a7ee5ed4b1ffd250eecaeefe5c", null ],
    [ "ARM_ETH_MAC_FLUSH", "group__eth__mac__ctrls.html#ga530812ef349a2e297f23de72e660fe27", null ],
    [ "ARM_ETH_MAC_SLEEP", "group__eth__mac__ctrls.html#ga4afe66589216f566f529af52f9075fdf", null ],
    [ "ARM_ETH_MAC_VLAN_FILTER", "group__eth__mac__ctrls.html#gab332b58ba320e73864830dc42ad74181", null ]
];