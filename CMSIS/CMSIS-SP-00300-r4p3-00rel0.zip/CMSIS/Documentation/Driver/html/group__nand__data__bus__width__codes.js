var group__nand__data__bus__width__codes =
[
    [ "ARM_NAND_BUS_DATA_WIDTH_16", "group__nand__data__bus__width__codes.html#ga49e0e3a946a4d9f26dbd5b32ccc3b2f3", null ],
    [ "ARM_NAND_BUS_DATA_WIDTH_8", "group__nand__data__bus__width__codes.html#ga578051cc193ae0b7125aec8007071d21", null ]
];