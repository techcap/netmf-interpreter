var group__usb__interface__gr =
[
    [ "USB Device Interface", "group__usbd__interface__gr.html", "group__usbd__interface__gr" ],
    [ "USB Host Interface", "group__usbh__interface__gr.html", "group__usbh__interface__gr" ],
    [ "USB Speed", "group___u_s_b__speed.html", "group___u_s_b__speed" ],
    [ "USB Endpoint Type", "group___u_s_b__endpoint__type.html", "group___u_s_b__endpoint__type" ]
];