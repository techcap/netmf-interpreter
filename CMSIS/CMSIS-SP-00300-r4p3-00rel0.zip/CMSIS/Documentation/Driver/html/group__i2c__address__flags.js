var group__i2c__address__flags =
[
    [ "ARM_I2C_ADDRESS_10BIT", "group__i2c__address__flags.html#ga16be1861b90774bf062feab2dbb829a4", null ],
    [ "ARM_I2C_ADDRESS_GC", "group__i2c__address__flags.html#ga337f4f1aa082e9b593b2dcd43c50134e", null ]
];