var group__sai__slot__control =
[
    [ "ARM_SAI_SLOT_COUNT", "group__sai__slot__control.html#ga8f2cf3a212ca7fe389e00b082efb5d0b", null ],
    [ "ARM_SAI_SLOT_OFFSET", "group__sai__slot__control.html#ga48d4a142f3a1bb0fa4e88c9e427932a0", null ],
    [ "ARM_SAI_SLOT_SIZE_16", "group__sai__slot__control.html#ga2bb9cf53b07cac81fb0fe71de6c97c83", null ],
    [ "ARM_SAI_SLOT_SIZE_32", "group__sai__slot__control.html#gaaa5c4cc18a0f5668bc9f117874cd83dd", null ],
    [ "ARM_SAI_SLOT_SIZE_DEFAULT", "group__sai__slot__control.html#gad77c6c0de2a4e7223a0c42e1594f0a2c", null ]
];