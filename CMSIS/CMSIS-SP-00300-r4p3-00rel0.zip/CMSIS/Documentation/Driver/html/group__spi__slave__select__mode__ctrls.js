var group__spi__slave__select__mode__ctrls =
[
    [ "ARM_SPI_SS_MASTER_HW_INPUT", "group__spi__slave__select__mode__ctrls.html#ga8561bd0cc25ab2bb02b138c1c6a586cd", null ],
    [ "ARM_SPI_SS_MASTER_HW_OUTPUT", "group__spi__slave__select__mode__ctrls.html#ga07762709a40dc90aca85553f500c8761", null ],
    [ "ARM_SPI_SS_MASTER_SW", "group__spi__slave__select__mode__ctrls.html#gab5e319aa3f9d4d8c9ed92f0fe865f624", null ],
    [ "ARM_SPI_SS_MASTER_UNUSED", "group__spi__slave__select__mode__ctrls.html#gae19343adc7bd71408b51733171f99dc7", null ],
    [ "ARM_SPI_SS_SLAVE_HW", "group__spi__slave__select__mode__ctrls.html#ga2bd0d1f3ade2dc0cc48cc0593336ad70", null ],
    [ "ARM_SPI_SS_SLAVE_SW", "group__spi__slave__select__mode__ctrls.html#gad371f6ba0d12a57bdcc3217c351abfb0", null ]
];