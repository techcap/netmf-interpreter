var group__sai__execution__status =
[
    [ "ARM_SAI_ERROR_AUDIO_FREQ", "group__sai__execution__status.html#ga5021651816da0aa92561eed634ba7578", null ],
    [ "ARM_SAI_ERROR_BIT_ORDER", "group__sai__execution__status.html#gadcd0d44f0f6b691c4e84b30960c096e4", null ],
    [ "ARM_SAI_ERROR_CLOCK_POLARITY", "group__sai__execution__status.html#ga7810e77ec599b0f86073a8711c0655df", null ],
    [ "ARM_SAI_ERROR_COMPANDING", "group__sai__execution__status.html#ga4683468c258e1a8706afcce1e81356d1", null ],
    [ "ARM_SAI_ERROR_DATA_SIZE", "group__sai__execution__status.html#ga5c51cbd8c2d2fe4baae110d390cefdc2", null ],
    [ "ARM_SAI_ERROR_FRAME_LENGHT", "group__sai__execution__status.html#gaf0448bdd6d1ae33511d170b9ecc1e2d6", null ],
    [ "ARM_SAI_ERROR_FRAME_SYNC_EARLY", "group__sai__execution__status.html#ga09fe9b65d2be54ee1441606523291011", null ],
    [ "ARM_SAI_ERROR_FRAME_SYNC_POLARITY", "group__sai__execution__status.html#ga0561b0cc9577d944e0d39b582612e061", null ],
    [ "ARM_SAI_ERROR_FRAME_SYNC_WIDTH", "group__sai__execution__status.html#ga993da1bc0f6745795b364d84dec24e99", null ],
    [ "ARM_SAI_ERROR_MCLK_PIN", "group__sai__execution__status.html#ga0d910d4a638433e3b2326fc776da0f53", null ],
    [ "ARM_SAI_ERROR_MCLK_PRESCALER", "group__sai__execution__status.html#gabab9495d6c57e56604cb1a2ac7e75431", null ],
    [ "ARM_SAI_ERROR_MONO_MODE", "group__sai__execution__status.html#ga912bf004fce3a37709bbf69734802b4a", null ],
    [ "ARM_SAI_ERROR_PROTOCOL", "group__sai__execution__status.html#gaf4892425930608ad7a41fa5b49603b10", null ],
    [ "ARM_SAI_ERROR_SLOT_COUNT", "group__sai__execution__status.html#gaf52ee0cd13b6cb9c63acfe767ed5dfde", null ],
    [ "ARM_SAI_ERROR_SLOT_OFFESET", "group__sai__execution__status.html#ga4658a3143c891d8972446630b6a978cd", null ],
    [ "ARM_SAI_ERROR_SLOT_SIZE", "group__sai__execution__status.html#ga7bf825043ba857950a89817ff9b853d1", null ],
    [ "ARM_SAI_ERROR_SYNCHRONIZATION", "group__sai__execution__status.html#ga711cd889b4209df3f8fb01e4f2413c61", null ]
];