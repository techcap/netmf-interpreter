var group__sai__mclk__pres__control =
[
    [ "ARM_SAI_MCLK_PRESCALER", "group__sai__mclk__pres__control.html#ga2afa85cd335e75d8b9b06c9f47f3f4b0", null ]
];